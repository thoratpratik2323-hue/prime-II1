"""
Voice Engine for Prime AI.
Provides high-quality Male Speech Synthesis (Edge-TTS JARVIS / RyanNeural with David fallback)
and Speech-To-Text (Microphone via speech_recognition).
"""

from __future__ import annotations

import asyncio
import logging
import os
import queue
import re
import tempfile
import threading
import time
from typing import Callable, Optional

import edge_tts
import pygame
import pyttsx3
import speech_recognition as sr
from config import config

log = logging.getLogger("prime.voice")

# High quality male voice defaults
# Options: "en-GB-RyanNeural" (British JARVIS), "en-US-GuyNeural", "en-US-ChristopherNeural"
MALE_VOICE_NAME = os.getenv("MALE_VOICE_NAME", "en-GB-RyanNeural")


class VoiceEngine:
    def __init__(self):
        self.tts_queue: queue.Queue[Optional[str]] = queue.Queue()
        self.tts_thread: Optional[threading.Thread] = None
        self.stop_requested = False
        self._is_speaking = False
        self._tts_enabled = config.voice_output

        # Speech recognition
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True

        # Initialize pygame mixer for audio playback
        try:
            pygame.mixer.init()
        except Exception as e:
            log.warning("Could not init pygame.mixer: %s", e)

        # Start TTS background worker
        self._start_tts_worker()

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking

    @property
    def tts_enabled(self) -> bool:
        return self._tts_enabled

    @tts_enabled.setter
    def tts_enabled(self, val: bool):
        self._tts_enabled = bool(val)

    def _start_tts_worker(self):
        self.stop_requested = False
        self.tts_thread = threading.Thread(target=self._tts_worker, daemon=True)
        self.tts_thread.start()

    def _tts_worker(self):
        """Worker thread that executes TTS playback."""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        while not self.stop_requested:
            try:
                text = self.tts_queue.get(timeout=0.2)
            except queue.Empty:
                continue

            if text is None:
                break

            if not self._tts_enabled or not text.strip():
                self.tts_queue.task_done()
                continue

            self._is_speaking = True
            try:
                # 1. Try High Quality Edge-TTS Male Voice
                played = loop.run_until_complete(self._speak_edge_tts(text))
                if not played:
                    # 2. Fallback to pyttsx3 Male Voice (Microsoft David)
                    self._speak_pyttsx3_male(text)
            except Exception as e:
                log.warning("TTS error, trying pyttsx3 fallback: %s", e)
                try:
                    self._speak_pyttsx3_male(text)
                except Exception:
                    pass
            finally:
                self._is_speaking = False
                self.tts_queue.task_done()

    async def _speak_edge_tts(self, text: str) -> bool:
        """Synthesize with Edge-TTS male voice and play via pygame."""
        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
                temp_file = f.name

            comm = edge_tts.Communicate(
                text,
                MALE_VOICE_NAME,
                rate="+5%",
                volume="+100%",
                pitch="+0Hz"
            )
            await comm.save(temp_file)

            if not os.path.exists(temp_file) or os.path.getsize(temp_file) == 0:
                return False

            if not pygame.mixer.get_init():
                pygame.mixer.init()

            pygame.mixer.music.load(temp_file)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy() and not self.stop_requested:
                pygame.time.Clock().tick(15)

            pygame.mixer.music.stop()
            pygame.mixer.music.unload()
            return True
        except Exception as e:
            log.debug("Edge-TTS speech error: %s", e)
            return False
        finally:
            if temp_file and os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except Exception:
                    pass

    def _speak_pyttsx3_male(self, text: str):
        """Offline fallback using Windows native male voice (David)."""
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", config.voice_rate)
            engine.setProperty("volume", config.voice_volume)

            voices = engine.getProperty("voices")
            # Select David (male)
            for v in voices:
                if "david" in v.name.lower() or "male" in v.name.lower():
                    engine.setProperty("voice", v.id)
                    break

            engine.say(text)
            engine.runAndWait()
        except Exception as e:
            log.warning("pyttsx3 offline fallback error: %s", e)

    def speak(self, text: str):
        """Queue text to be spoken."""
        if not self._tts_enabled or not text:
            return
        clean_text = self._sanitize_for_tts(text)
        if clean_text:
            self.tts_queue.put(clean_text)

    def stop_speaking(self):
        """Cancel ongoing and queued speech."""
        while not self.tts_queue.empty():
            try:
                self.tts_queue.get_nowait()
                self.tts_queue.task_done()
            except Exception:
                break
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
        except Exception:
            pass

    def _sanitize_for_tts(self, text: str) -> str:
        """Clean markdown, code, and emojis for natural spoken audio."""
        # Code blocks
        text = re.sub(r"```[\s\S]*?```", " Code block created. ", text)
        # Inline code
        text = re.sub(r"`([^`]+)`", r"\1", text)
        # Markdown links [title](url) -> title
        text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
        # Headers & bullets
        text = re.sub(r"^[#*>\-\s]+", "", text, flags=re.MULTILINE)
        # Emojis & special symbols
        text = re.sub(r"[\U00010000-\U0010ffff]", "", text)
        return text.strip()

    def listen(self, status_callback: Optional[Callable[[str], None]] = None) -> Optional[str]:
        """Listen to the default microphone and return recognized text."""
        try:
            with sr.Microphone() as source:
                if status_callback:
                    status_callback("Adjusting for background noise...")
                self.recognizer.adjust_for_ambient_noise(source, duration=0.8)

                if status_callback:
                    status_callback("Listening... (speak now)")
                audio = self.recognizer.listen(source, timeout=6, phrase_time_limit=15)

                if status_callback:
                    status_callback("Transcribing speech...")

                text = self.recognizer.recognize_google(audio)
                return text.strip()
        except sr.WaitTimeoutError:
            if status_callback:
                status_callback("Listening timed out (no speech detected).")
            return None
        except sr.UnknownValueError:
            if status_callback:
                status_callback("Could not understand audio.")
            return None
        except sr.RequestError as e:
            if status_callback:
                status_callback(f"Speech recognition service error: {e}")
            return None
        except Exception as e:
            if status_callback:
                status_callback(f"Microphone error: {e}")
            return None


voice = VoiceEngine()

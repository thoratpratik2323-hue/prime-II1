"""
PRIME AI :: AUTONOMOUS NEURAL COCKPIT
Cyberpunk CLI Interface with Real-Time Telemetry & Ambient Voice Link.
"""

from __future__ import annotations

import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import psutil
from rich.align import Align
from rich.columns import Columns
from rich.console import Console, Group
from rich.layout import Layout
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress_bar import ProgressBar
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style as PTStyle

from ai_agent import agent
from config import config
import providers
from tool_definitions import TOOL_SPECS, execute_tool
from voice_engine import voice

# Force UTF-8 on Windows
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Cyberpunk Neon Theme
custom_theme = Theme({
    "info": "bold cyan",
    "warning": "bold yellow",
    "error": "bold red",
    "success": "bold green",
    "command": "bold magenta",
    "ai": "bold bright_cyan",
    "user": "bold bright_white",
    "tool": "bold bright_yellow",
    "dim": "dim cyan",
    "highlight": "bold bright_magenta",
    "neon_blue": "bold bright_blue",
    "neon_green": "bold bright_green",
    "neon_pink": "bold bright_magenta",
})
console = Console(theme=custom_theme)

# Session Telemetry
SESSION_START = time.time()
SESSION_STATS = {
    "queries": 0,
    "tool_calls": 0,
    "last_latency_ms": 0.0,
}

# Slash Commands Auto-completer
SLASH_COMMANDS = [
    "/menu",
    "/v", "/mic", "/voice",
    "/listen",
    "/hud",
    "/providers",
    "/switch",
    "/ping",
    "/key",
    "/stats",
    "/weather",
    "/briefing",
    "/notes",
    "/git",
    "/tools",
    "/agents", "/persona", "/activate", "/deactivate",
    "/goal", "/refine", "/lessons",
    "/system",
    "/speak",
    "/clear",
    "/help",
    "/exit", "quit"
]
completer = WordCompleter(SLASH_COMMANDS, ignore_case=True, sentence=True)

HISTORY_FILE = Path.home() / ".prime_history"
_session = None


def get_user_input(prompt_text: str = "⚡ PRIME ❯ ") -> str:
    """Safely get user input with prompt_toolkit or fallback to console.input."""
    global _session
    if _session is None:
        try:
            from prompt_toolkit.output.win32 import NoConsoleScreenBufferError
            _session = PromptSession(history=FileHistory(str(HISTORY_FILE)), completer=completer)
        except Exception:
            _session = False  # Mark fallback

    if _session and _session is not False:
        try:
            return _session.prompt(prompt_text).strip()
        except Exception:
            pass

    return console.input(f"[bold cyan]{prompt_text}[/bold cyan]").strip()


def format_bar(percent: float, width: int = 14) -> str:
    """ASCII progress meter with color grading."""
    filled = int(width * (percent / 100.0))
    filled = max(0, min(width, filled))
    empty = width - filled
    
    if percent < 60:
        bar_color = "bright_green"
    elif percent < 85:
        bar_color = "bright_yellow"
    else:
        bar_color = "bright_red"

    bar = f"[{bar_color}]{'█' * filled}[/{bar_color}][dim]{'░' * empty}[/dim]"
    return f"{bar} {percent:4.1f}%"


def get_waveform_visualizer() -> str:
    """Simulates a sleek audio frequency equalizer."""
    return "[bright_cyan] ▂[/bright_cyan][cyan]▃[/cyan][bright_blue]▅[/bright_blue][bright_magenta]▆[/bright_magenta][magenta]▇[/magenta][bright_magenta]▆[/bright_magenta][bright_blue]▅[/bright_blue][cyan]▃[/cyan][bright_cyan]▂ [/bright_cyan]"


def print_banner():
    """Renders the high-tech Cyberpunk HUD Cockpit Banner."""
    console.clear()

    ascii_logo = """
  ██████╗ ██████╗ ██╗███╗   ███╗███████╗     █████╗ ██╗
  ██╔══██╗██╔══██╗██║████╗ ████║██╔════╝    ██╔══██╗██║
  ██████╔╝██████╔╝██║██╔████╔██║█████╗      ███████║██║
  ██╔═══╝ ██╔══██╗██║██║╚██╔╝██║██╔══╝      ██╔══██║██║
  ██║     ██║  ██║██║██║ ╚═╝ ██║███████╗    ██║  ██║██║
  ╚═╝     ╚═╝  ╚═╝╚═╝╚═╝     ╚═╝╚══════╝    ╚═╝  ╚═╝╚═╝
    """

    logo_text = Text(ascii_logo, style="bold cyan")
    tagline = Text("  ⚡ AUTONOMOUS NEURAL COCKPIT :: ZERO GUI · 24/7 AMBIENT VOICE · PURE POWER  ", style="bold bright_white on dark_blue")

    header_group = Group(
        Align.center(logo_text),
        Align.center(tagline),
        Text(""),
    )
    console.print(header_group)

    # Telemetry Panel
    provider_id = config.get_active_provider()
    prov_info = providers.get_provider_by_id(provider_id)
    prov_display = prov_info["name"] if prov_info else provider_id.upper()
    tts_status = "[bold bright_green]ONLINE[/bold bright_green] (British Male Ryan)" if voice.tts_enabled else "[bold red]MUTED[/bold red]"
    
    # Left: AI Core & Neural State
    t_left = Table(show_header=False, box=None, padding=(0, 1))
    t_left.add_row("[bold cyan]Operator:[/bold cyan]", "[bold bright_white]Pratik Thorat[/bold bright_white]")
    t_left.add_row("[bold cyan]Neural Brain:[/bold cyan]", f"[bold bright_green]{config.default_model}[/bold bright_green] ([bold magenta]{prov_display}[/bold magenta])")
    t_left.add_row("[bold cyan]Spoken Voice:[/bold cyan]", f"{tts_status} {get_waveform_visualizer()}")
    t_left.add_row("[bold cyan]Tool Arsenal:[/bold cyan]", f"[bold bright_cyan]{len(TOOL_SPECS)} Active Modules[/bold bright_cyan] (Desktop + Code + SAT)")
    t_left.add_row("[bold cyan]Ambient Voice:[/bold cyan]", "[bold bright_green]● LIVE 24/7[/bold bright_green] [dim](Hands-free open mic)[/dim]")
    persona_name = agent.active_persona["display_name"] if agent.active_persona else "Prime Core (Operator)"
    t_left.add_row("[bold cyan]Active Persona:[/bold cyan]", f"[bold bright_magenta]🎭 {persona_name}[/bold bright_magenta]")
    from prime_goal_harness import goal_tracker
    active_goal = goal_tracker.get_active_goal()
    if active_goal:
        goal_disp = f"[bold bright_yellow]{active_goal['objective'][:30]}[/bold bright_yellow] [dim]({active_goal['progress_percent']:.0f}%)[/dim]"
    else:
        goal_disp = "[dim]No active goal set (use /goal)[/dim]"
    t_left.add_row("[bold cyan]Active Goal:[/bold cyan]", f"🎯 {goal_disp}")

    # Right: Host Hardware Vitals
    cpu_pct = psutil.cpu_percent()
    ram_pct = psutil.virtual_memory().percent
    disk_pct = psutil.disk_usage(".").percent

    bat_str = "A/C Mains"
    if hasattr(psutil, "sensors_battery"):
        bat = psutil.sensors_battery()
        if bat:
            bat_str = f"{bat.percent}% {'(⚡ Plugged)' if bat.power_plugged else '(🔋 Battery)'}"

    uptime_sec = int(time.time() - SESSION_START)
    uptime_str = f"{uptime_sec // 60}m {uptime_sec % 60}s"

    t_right = Table(show_header=False, box=None, padding=(0, 1))
    t_right.add_row("[bold cyan]CPU Load:[/bold cyan]", f"{format_bar(cpu_pct)}")
    t_right.add_row("[bold cyan]RAM Usage:[/bold cyan]", f"{format_bar(ram_pct)}")
    t_right.add_row("[bold cyan]Storage Usage:[/bold cyan]", f"{format_bar(disk_pct)}")
    t_right.add_row("[bold cyan]Power State:[/bold cyan]", f"[bold bright_cyan]{bat_str}[/bold bright_cyan]")
    t_right.add_row("[bold cyan]Cockpit Uptime:[/bold cyan]", f"[bold bright_white]{uptime_str}[/bold bright_white]")

    p_left = Panel(t_left, title="[bold bright_white]⚡ NEURAL CORE STATUS[/bold bright_white]", border_style="bright_cyan")
    p_right = Panel(t_right, title="[bold bright_white]🖥️ HOST TELEMETRY[/bold bright_white]", border_style="bright_cyan")

    console.print(Columns([p_left, p_right], expand=True))
    console.print(Rule(style="dim cyan"))
    console.print("[dim cyan]Type any prompt to talk, [bold bright_white]/menu[/bold bright_white] for command hub, [bold bright_white]/v[/bold bright_white] for mic, [bold bright_white]/providers[/bold bright_white] for free LLMs, or [bold bright_white]/help[/bold bright_white].[/dim cyan]\n")


def print_menu():
    """Interactive quick access menu."""
    table = Table(title="⚡ PRIME COMMAND COCKPIT MENU", border_style="bright_cyan", header_style="bold bright_cyan")
    table.add_column("Key", style="bold bright_magenta", justify="center", width=6)
    table.add_column("Quick Action", style="bold bright_white", width=32)
    table.add_column("Description", style="dim cyan")

    table.add_row("[1]", "🎙️  Start 24/7 Voice Mode", "Hands-free ambient voice assistant (open mic)")
    table.add_row("[2]", "⚡  Live Telemetry Cockpit (HUD)", "Real-time auto-refreshing CPU, RAM, Disk gauges")
    table.add_row("[3]", "🔄  Switch LLM Provider", "Select Groq, Cerebras, GitHub Models, Gemini, OpenRouter, etc.")
    table.add_row("[4]", "🔑  Configure API Keys", "Quickly save free provider API keys to .env")
    table.add_row("[5]", "🐙  Claw Code Git Control", "Autonomous Git commit, diff review & push")
    table.add_row("[6]", "📚  Obsidian Second Brain", "Search & browse markdown knowledge vault")
    table.add_row("[7]", "🛠️  Browse 44 Automation Tools", "Explore Desktop, Media, Filesystem & Dev tools")
    table.add_row("[8]", "🌅  Personalized Morning Briefing", "Trigger voice daily summary with weather & tasks")
    table.add_row("[9]", "🌦️  Live Weather Forecast", "Instant meteorological report for your city")
    table.add_row("[10]", "⏱️  Benchmark Provider Latency", "Test round-trip response speed of active AI core")
    table.add_row("[11]", "📊  Session Performance Stats", "View total queries, tool executions & uptime")
    table.add_row("[12]", "🧹  Clear & Redraw HUD", "Clean terminal buffer and render fresh cockpit")
    table.add_row("[0]", "🚪  Exit Prime AI", "Power down neural cockpit session")

    console.print(table)
    console.print("[dim cyan]Enter number [bold bright_white]1-12[/bold bright_white] or command name directly.[/dim cyan]\n")


def print_help():
    table = Table(title="⚡ PRIME COMMAND MATRIX", border_style="bright_cyan", header_style="bold bright_cyan")
    table.add_column("Command", style="bold bright_magenta", no_wrap=True)
    table.add_column("Action & Description", style="white")

    table.add_row("/menu", "Open interactive numbered command menu")
    table.add_row("/v, /mic, /voice", "One-shot voice command: records audio and executes immediately")
    table.add_row("/listen", "Start 24/7 continuous ambient listening loop in the current terminal")
    table.add_row("/hud", "Open full-screen live refreshing telemetry dashboard")
    table.add_row("/providers", "Browse 9 curated permanently free LLM providers (from awesome-free-llm-apis)")
    table.add_row("/switch [provider_id]", "Switch active LLM provider (e.g. /switch groq)")
    table.add_row("/ping", "Test round-trip response latency of the active AI model")
    table.add_row("/key <provider> <key>", "Store free API key into .env permanently")
    table.add_row("/stats", "Display session runtime metrics, queries, and tool invocations")
    table.add_row("/weather [city]", "Fetch instant live meteorological forecast for any city")
    table.add_row("/briefing", "Trigger comprehensive personalized morning voice briefing")
    table.add_row("/notes [query]", "Search user's Obsidian Vault Markdown second brain")
    table.add_row("/git [action]", "Run automated Git commands (status, diff, commit, push)")
    table.add_row("/tools [filter]", "Browse all 44 desktop & developer automation tools")
    table.add_row("/system", "Detailed hardware vitals report (CPU, RAM, Disks, Battery)")
    table.add_row("/speak on|off", "Toggle neural speech voice output")
    table.add_row("/clear", "Clear terminal display and redraw HUD")
    table.add_row("/exit, quit", "Shutdown Prime AI session")

    console.print(table)


def print_tools(filter_kw: Optional[str] = None):
    table = Table(title=f"⚡ TOOL ARSENAL ({len(TOOL_SPECS)} Active Capabilities)", border_style="bright_cyan")
    table.add_column("Tool Name", style="bold bright_cyan", no_wrap=True)
    table.add_column("Category", style="bold bright_magenta")
    table.add_column("Capability Description", style="white")

    for spec in TOOL_SPECS:
        name = spec["name"]
        desc = spec["description"]

        if "Obsidian" in name:
            cat = "Knowledge"
        elif any(w in name for w in ("Terminal", "patch", "git", "Test", "debug")):
            cat = "Claw Dev"
        elif any(w in name for w in ("App", "Website", "Window")):
            cat = "Desktop"
        elif any(w in name for w in ("Volume", "Media", "spotify")):
            cat = "Audio"
        elif any(w in name for w in ("weather", "briefing")):
            cat = "Routines"
        elif any(w in name for w in ("File", "Directory")):
            cat = "Filesystem"
        else:
            cat = "Core"

        if filter_kw and filter_kw.lower() not in (name + desc + cat).lower():
            continue

        table.add_row(name, cat, desc)

    console.print(table)


def print_agency_agents(filter_kw: Optional[str] = None):
    import agency_roster
    agents = agency_roster.load_all_agency_agents()
    table = Table(title=f"⚡ AGENCY AGENTS ROSTER ({len(agents)} Specialist Personas Available)", border_style="bright_magenta")
    table.add_column("Agent ID", style="bold bright_magenta", no_wrap=True)
    table.add_column("Specialist Role", style="bold bright_white")
    table.add_column("Division", style="bold cyan")
    table.add_column("Description", style="dim white")

    shown = 0
    for aid, a in agents.items():
        if filter_kw:
            kw = filter_kw.lower()
            if kw not in (aid + a["display_name"] + a["category"] + a["description"]).lower():
                continue
        table.add_row(aid, a["display_name"], a["category"], a["description"][:100] + ("..." if len(a["description"]) > 100 else ""))
        shown += 1
        if not filter_kw and shown >= 35:
            break

    console.print(table)
    if not filter_kw:
        console.print(f"[dim cyan]Showing first 35 of {len(agents)} agents. Use [bold bright_white]/agents <division>[/bold bright_white] (e.g. /agents security, /agents engineering, /agents design) to search.[/dim cyan]")
    console.print("[dim cyan]To activate: [bold bright_white]/activate <agent_id>[/bold bright_white] or speak: [bold bright_white]\"Prime, activate Frontend Developer\"[/bold bright_white][/dim cyan]\n")


def print_providers():
    table = Table(title="⚡ FREE LLM PROVIDER DIRECTORY (Curated from awesome-free-llm-apis)", border_style="bright_cyan")
    table.add_column("ID", style="bold bright_magenta", no_wrap=True)
    table.add_column("Provider Name", style="bold bright_white")
    table.add_column("Status", justify="center")
    table.add_column("Inference Speed", style="dim bright_cyan")
    table.add_column("Free Tier Limits", style="dim white")
    table.add_column("Key Signup Link", style="bold yellow")

    active_provider = config.get_active_provider()

    for p in providers.get_providers_list():
        p_id = p["id"]
        is_active = (p_id == active_provider)
        is_cfg = providers.is_provider_configured(p_id)

        if is_active:
            status_badge = "[bold bright_green]● ACTIVE[/bold bright_green]"
        elif is_cfg:
            status_badge = "[bold green]✓ READY[/bold green]"
        else:
            status_badge = "[dim yellow]○ NO KEY[/dim yellow]"

        table.add_row(
            f"{p_id}",
            p["name"],
            status_badge,
            p.get("speed", "Fast"),
            p["free_tier"],
            p["signup_url"]
        )

    console.print(table)
    console.print("[dim cyan]To switch: [bold bright_white]/switch <provider_id>[/bold bright_white]  |  To add key: [bold bright_white]/key <provider_id> <api_key>[/bold bright_white][/dim cyan]\n")


def ping_active_provider():
    """Benchmark the round-trip latency of the active LLM provider."""
    provider = config.get_active_provider()
    model = config.get_default_model(provider)
    console.print(f"[bold cyan]⚡ Measuring latency to [bold bright_white]{provider.upper()}[/bold bright_white] ({model})...[/bold cyan]")
    
    t0 = time.time()
    try:
        response = agent.process_message("ping - return only the single word: PONG")
        latency = (time.time() - t0) * 1000.0
        SESSION_STATS["last_latency_ms"] = latency
        console.print(f"[bold bright_green]✓ Round-trip latency:[/bold bright_green] [bold bright_white]{latency:.1f} ms[/bold bright_white] | Response: [dim]{response.strip()[:40]}[/dim]")
    except Exception as e:
        console.print(f"[bold red]✗ Latency test failed:[/bold red] {e}")


def print_stats():
    """Display session performance stats."""
    uptime_sec = int(time.time() - SESSION_START)
    table = Table(title="⚡ PRIME SESSION METRICS", border_style="bright_cyan")
    table.add_column("Metric", style="bold cyan")
    table.add_column("Value", style="bold bright_white")

    table.add_row("Session Uptime", f"{uptime_sec // 3600}h {(uptime_sec % 3600) // 60}m {uptime_sec % 60}s")
    table.add_row("Neural Queries Handled", str(SESSION_STATS["queries"]))
    table.add_row("Autonomous Tools Executed", str(SESSION_STATS["tool_calls"]))
    table.add_row("Last Round-trip Latency", f"{SESSION_STATS['last_latency_ms']:.1f} ms" if SESSION_STATS['last_latency_ms'] else "Not measured (use /ping)")
    table.add_row("Active LLM Core", f"{config.get_active_provider().upper()} ({config.default_model})")
    table.add_row("Voice Output State", "ONLINE (British Male Ryan)" if voice.tts_enabled else "MUTED")
    console.print(table)


def render_live_hud(duration: int = 10):
    """Full-screen live-refreshing hardware & telemetry HUD."""
    console.print(f"[bold cyan]Launching Live Telemetry Cockpit ({duration}s)... Press Ctrl+C to exit.[/bold cyan]")

    def generate_hud_table():
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        disk = psutil.disk_usage(".").percent

        t = Table(title=f"⚡ PRIME TELEMETRY COCKPIT — {datetime.now().strftime('%H:%M:%S')}", border_style="bright_cyan", expand=True)
        t.add_column("Telemetry Sensor", style="bold cyan")
        t.add_column("Current Metric", style="bold white")
        t.add_column("Visual Gauge", style="bold bright_green")

        t.add_row("CPU Load", f"{cpu:4.1f} %", format_bar(cpu, width=28))
        t.add_row("RAM Occupancy", f"{ram:4.1f} %", format_bar(ram, width=28))
        t.add_row("Storage Utilization", f"{disk:4.1f} %", format_bar(disk, width=28))

        if hasattr(psutil, "cpu_freq") and psutil.cpu_freq():
            freq = psutil.cpu_freq().current
            t.add_row("CPU Frequency", f"{freq:.0f} MHz", "[bold cyan]Active Dynamic Core[/bold cyan]")

        t.add_row("Active Arsenal", f"{len(TOOL_SPECS)} Tools", "[bold bright_green]100% Armed & Ready[/bold bright_green]")
        t.add_row("Audio Waveform", get_waveform_visualizer(), "[bold bright_cyan]Voice Bus Online[/bold bright_cyan]")
        return Panel(t, border_style="bright_cyan", padding=(1, 2))

    try:
        with Live(generate_hud_table(), refresh_per_second=2, console=console) as live:
            for _ in range(duration * 2):
                time.sleep(0.5)
                live.update(generate_hud_table())
    except KeyboardInterrupt:
        pass
    console.print("[dim cyan]Live Telemetry closed.[/dim cyan]\n")


def on_tool_call(name: str, args: dict):
    SESSION_STATS["tool_calls"] += 1
    arg_summary = ", ".join(f"[bold cyan]{k}[/bold cyan]={v!r}" for k, v in args.items()) if args else "no args"
    console.print(f" [bold bright_yellow]⚡ NEURAL TOOL EXECUTION[/bold bright_yellow] → [bold bright_white]{name}[/bold bright_white]({arg_summary})")


def on_tool_result(name: str, result: dict):
    if result.get("ok"):
        res = result.get("result", {})
        msg = res.get("result", res) if isinstance(res, dict) else str(res)
        preview = str(msg).strip()
        if len(preview) > 180:
            preview = preview[:180] + "..."
        console.print(f" [bold bright_green]✓ COMPLETED[/bold bright_green] [bold cyan]{name}[/bold cyan] → [dim bright_white]{preview}[/dim bright_white]")
    else:
        err = result.get("error", "Action failed.")
        console.print(f" [bold red]✗ TOOL ERROR[/bold red] [bold cyan]{name}[/bold cyan] → [bold red]{err}[/bold red]")


def handle_user_query(query: str):
    if not query.strip():
        return

    SESSION_STATS["queries"] += 1
    console.print(f"\n[bold bright_cyan]❯ OPERATOR:[/bold bright_cyan] [bold bright_white]{query}[/bold bright_white]")

    t0 = time.time()
    with console.status("[bold bright_cyan]⚡ Prime Neural Brain is reasoning...[/bold bright_cyan]", spinner="dots12"):
        response = agent.process_message(
            query,
            on_tool_call=on_tool_call,
            on_tool_result=on_tool_result,
        )
    elapsed = (time.time() - t0) * 1000.0
    SESSION_STATS["last_latency_ms"] = elapsed

    # Render response in a styled cyberpunk panel
    md = Markdown(response)
    panel = Panel(
        md,
        title=f"[bold bright_cyan]⚡ PRIME AI[/bold bright_cyan] [dim]({elapsed:.0f}ms)[/dim]",
        border_style="bright_cyan",
        padding=(1, 2),
    )
    console.print(panel)


def listen_continuous():
    """Continuous ambient voice listening loop directly in the terminal."""
    console.print("\n[bold cyan]╔═════════════════════════════════════════════════════════════╗[/bold cyan]")
    console.print("[bold bright_white]║  🎙️ STARTING 24/7 CONTINUOUS AMBIENT VOICE LOOP (OPEN-MIC)  ║[/bold bright_white]")
    console.print("[dim]║  Speak commands naturally. Say 'exit voice' to return.      ║[/dim]")
    console.print("[bold cyan]╚═════════════════════════════════════════════════════════════╝[/bold cyan]\n")

    import speech_recognition as sr
    r = sr.Recognizer()
    r.dynamic_energy_threshold = False
    r.energy_threshold = 300
    r.pause_threshold = 0.8

    mic_index = None
    try:
        from voice_assistant import get_active_microphone_index
        mic_index = get_active_microphone_index()
    except Exception:
        pass

    try:
        with sr.Microphone(device_index=mic_index) as source:
            console.print("[bold bright_green]● MICROPHONE LIVE — Listening 24/7... (Press Ctrl+C to exit)[/bold bright_green]\n")
            while True:
                try:
                    audio = r.listen(source, timeout=None, phrase_time_limit=10)
                    console.print("[dim cyan]⚡ Sound captured... transcribing[/dim cyan]")
                    text = r.recognize_google(audio)
                    if text.strip():
                        console.print(f"\n🎤 [bold bright_white]Heard:[/bold bright_white] \"{text}\"")
                        if "exit voice" in text.lower():
                            console.print("[yellow]Exiting continuous voice mode.[/yellow]")
                            break
                        handle_user_query(text)
                        console.print("\n[bold bright_green]● MICROPHONE LIVE — Listening...[/bold bright_green]")
                except sr.UnknownValueError:
                    pass
                except sr.WaitTimeoutError:
                    pass
    except KeyboardInterrupt:
        console.print("\n[dim yellow]Voice loop stopped by user.[/dim yellow]\n")


def get_prompt_text() -> str:
    """Builds a dynamic futuristic prompt string."""
    provider = config.get_active_provider().upper()
    persona_tag = f" :: 🎭 {agent.active_persona['display_name'].upper()}" if agent.active_persona else ""
    return f"╭─[⚡ PRIME :: {provider}{persona_tag}]─[🎙️ LIVE]─[🟢 READY]\n╰─❯ "


def main():
    print_banner()

    while True:
        try:
            prompt_str = get_prompt_text()
            user_input = get_user_input(prompt_str)
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim cyan]Shutting down Prime AI cockpit. Systems offline.[/dim cyan]")
            break

        if not user_input:
            continue

        cmd_lower = user_input.lower().strip()

        # Numeric Menu Shortcuts
        if cmd_lower == "1":
            listen_continuous()
            continue
        elif cmd_lower == "2":
            render_live_hud(10)
            continue
        elif cmd_lower == "3":
            print_providers()
            continue
        elif cmd_lower == "4":
            console.print("[dim cyan]Usage: [bold bright_white]/key <provider_id> <your_key>[/bold bright_white] (e.g. /key groq gsk_...)[/dim cyan]")
            continue
        elif cmd_lower == "5":
            res = execute_tool("gitAutomate", {"action": "status"})
            console.print(Panel(str(res), title="[bold cyan]🐙 GIT STATUS[/bold cyan]", border_style="cyan"))
            continue
        elif cmd_lower == "6":
            query = console.input("[bold cyan]Enter search query for Obsidian Vault: [/bold cyan]").strip()
            if query:
                res = execute_tool("searchObsidianNotes", {"query": query})
                console.print(Panel(str(res.get("result", "")), title=f"[bold cyan]📚 OBSIDIAN RESULTS: '{query}'[/bold cyan]", border_style="cyan"))
            continue
        elif cmd_lower == "7":
            print_tools()
            continue
        elif cmd_lower == "8":
            with console.status("[bold cyan]Generating Morning Briefing...[/bold cyan]"):
                res = execute_tool("morningBriefing", {"action": "briefing"})
            console.print(Panel(res.get("result", ""), title="[bold cyan]🌅 MORNING BRIEFING[/bold cyan]", border_style="cyan"))
            continue
        elif cmd_lower == "9":
            city = console.input("[bold cyan]Enter city name (default Pune): [/bold cyan]").strip() or "Pune"
            res = execute_tool("getWeather", {"city": city})
            console.print(f"[bold bright_green]{res.get('result', res)}[/bold bright_green]")
            continue
        elif cmd_lower == "10":
            ping_active_provider()
            continue
        elif cmd_lower == "11":
            print_stats()
            continue
        elif cmd_lower == "12":
            print_banner()
            continue
        elif cmd_lower == "0":
            console.print("[bold cyan]Powering down Prime AI neural cockpit. Good day, Sir.[/bold cyan]")
            break

        # Command Routing
        if cmd_lower in ("/exit", "quit", "exit", "/quit"):
            console.print("[bold cyan]Shutting down Prime AI. Good day, Sir.[/bold cyan]")
            break

        elif cmd_lower in ("/clear", "cls"):
            print_banner()

        elif cmd_lower == "/menu":
            print_menu()

        elif cmd_lower == "/help":
            print_help()

        elif cmd_lower == "/stats":
            print_stats()

        elif cmd_lower == "/ping":
            ping_active_provider()

        elif cmd_lower.startswith("/tools"):
            parts = user_input.split(maxsplit=1)
            filter_kw = parts[1].strip() if len(parts) > 1 else None
            print_tools(filter_kw)

        elif cmd_lower == "/hud":
            render_live_hud(10)

        elif cmd_lower == "/listen":
            listen_continuous()

        elif cmd_lower.startswith(("/agents", "/personas")):
            parts = user_input.split(maxsplit=1)
            filter_kw = parts[1].strip() if len(parts) > 1 else None
            print_agency_agents(filter_kw)

        elif cmd_lower.startswith(("/activate", "/persona")):
            parts = user_input.split(maxsplit=1)
            if len(parts) > 1:
                target = parts[1].strip().lower()
                if target in ("reset", "deactivate", "prime", "default"):
                    agent.deactivate_persona()
                    console.print("[bold cyan]✓ Deactivated specialist persona. Prime Neural Cockpit restored.[/bold cyan]")
                else:
                    activated = agent.activate_persona(target)
                    if activated:
                        console.print(f"[bold bright_magenta]✓ Activated Specialist Persona: {activated}[/bold bright_magenta]")
                    else:
                        console.print(f"[yellow]Could not find persona matching '{target}'. Use /agents to browse all 279 specialists.[/yellow]")
            else:
                curr = agent.active_persona["display_name"] if agent.active_persona else "Default Prime Cockpit"
                console.print(f"[cyan]Current Active Persona: [bold bright_magenta]{curr}[/bold bright_magenta][/cyan]")
                console.print("[dim cyan]Usage: [bold bright_white]/activate <name>[/bold bright_white] or [bold bright_white]/deactivate[/bold bright_white][/dim cyan]")

        elif cmd_lower in ("/deactivate", "/reset_persona"):
            agent.deactivate_persona()
            console.print("[bold cyan]✓ Deactivated specialist persona. Prime Neural Cockpit restored.[/bold cyan]")

        elif cmd_lower.startswith("/goal"):
            from prime_goal_harness import goal_tracker
            parts = user_input.split(maxsplit=1)
            if len(parts) > 1:
                arg = parts[1].strip()
                if arg.lower() in ("clear", "cancel", "reset"):
                    goal_tracker.clear_active_goal()
                    console.print("[yellow]Active goal cleared.[/yellow]")
                elif arg.lower() in ("done", "finish", "complete"):
                    g = goal_tracker.complete_active_goal("Goal completed by user.")
                    console.print(f"[bold bright_green]✓ Goal completed: {g['objective'] if g else ''}[/bold bright_green]")
                elif arg.lower().startswith("progress"):
                    p_parts = arg.split(maxsplit=2)
                    pct = float(p_parts[1]) if len(p_parts) > 1 else 50.0
                    note = p_parts[2] if len(p_parts) > 2 else ""
                    g = goal_tracker.update_progress(pct, note=note)
                    console.print(f"[bold cyan]✓ Goal progress updated to {pct:.0f}%[/bold cyan]")
                else:
                    g = goal_tracker.set_goal(arg)
                    console.print(f"[bold bright_green]🎯 Persistent Goal Set:[/bold bright_green] [bold bright_white]{g['objective']}[/bold bright_white]")
            else:
                g = goal_tracker.get_active_goal()
                if g:
                    console.print(Panel(f"[bold white]{g['objective']}[/bold white]\n[cyan]Progress:[/cyan] [bold bright_green]{g['progress_percent']:.0f}%[/bold bright_green]\n[dim]Status: {g['status']}[/dim]", title="🎯 CURRENT PERSISTENT GOAL", border_style="bright_yellow"))
                else:
                    console.print("[dim]No active goal set. Type: [bold bright_white]/goal <your goal>[/bold bright_white][/dim]")

        elif cmd_lower.startswith("/refine"):
            from prime_goal_harness import continual_harness
            parts = user_input.split(maxsplit=1)
            if len(parts) > 1:
                text = parts[1].strip()
                if "=" in text:
                    topic, insight = text.split("=", 1)
                elif ":" in text:
                    topic, insight = text.split(":", 1)
                else:
                    topic, insight = "General", text
                l = continual_harness.record_lesson(topic.strip(), insight.strip(), source="operator_cli")
                console.print(f"[bold bright_green]✓ Learned Lesson Recorded:[/bold bright_green] [bold cyan]{l['topic']}[/bold cyan] → [dim bright_white]{l['insight']}[/dim bright_white]")
            else:
                console.print("[yellow]Usage: /refine <topic> = <insight / rule / preference>[/yellow]")

        elif cmd_lower == "/lessons":
            from prime_goal_harness import continual_harness
            lessons = continual_harness.get_lessons(limit=15)
            t = Table(title="⚡ CONTINUAL HARNESS LESSONS & LEARNED PATTERNS", border_style="bright_cyan")
            t.add_column("#", justify="center", style="dim")
            t.add_column("Topic", style="bold cyan")
            t.add_column("Learned Insight / Habit", style="white")
            for l in lessons:
                t.add_row(str(l.get("id", "-")), l.get("topic", ""), l.get("insight", ""))
            console.print(t)

        elif cmd_lower.startswith("/weather"):
            parts = user_input.split(maxsplit=1)
            city = parts[1].strip() if len(parts) > 1 else "Pune"
            res = execute_tool("getWeather", {"city": city})
            console.print(f"[bold bright_green]{res.get('result', res)}[/bold bright_green]")

        elif cmd_lower == "/briefing":
            with console.status("[bold cyan]Generating Morning Briefing...[/bold cyan]"):
                res = execute_tool("morningBriefing", {"action": "briefing"})
            console.print(Panel(res.get("result", ""), title="[bold cyan]🌅 MORNING BRIEFING[/bold cyan]", border_style="cyan"))

        elif cmd_lower.startswith("/notes"):
            parts = user_input.split(maxsplit=1)
            query = parts[1].strip() if len(parts) > 1 else ""
            if not query:
                console.print("[yellow]Usage: /notes <search query>[/yellow]")
            else:
                res = execute_tool("searchObsidianNotes", {"query": query})
                console.print(Panel(str(res.get("result", "")), title=f"[bold cyan]📚 OBSIDIAN RESULTS: '{query}'[/bold cyan]", border_style="cyan"))

        elif cmd_lower.startswith("/git"):
            parts = user_input.split(maxsplit=1)
            action = parts[1].strip() if len(parts) > 1 else "status"
            res = execute_tool("gitAutomate", {"action": action})
            console.print(Panel(str(res), title=f"[bold cyan]🐙 GIT: {action.upper()}[/bold cyan]", border_style="cyan"))

        elif cmd_lower.startswith(("/v", "/mic", "/voice")):
            console.print("[bold cyan]🎙️ Listening for single command... Speak now![/bold cyan]")
            audio_text = voice.listen_one_shot(timeout=7)
            if audio_text:
                console.print(f"[bold green]🎤 Recognized:[/bold green] \"{audio_text}\"")
                handle_user_query(audio_text)
            else:
                console.print("[dim yellow]No speech detected.[/dim yellow]")

        elif cmd_lower.startswith("/speak"):
            parts = user_input.split()
            if len(parts) > 1:
                arg = parts[1].lower()
                if arg in ("on", "1", "true"):
                    voice.tts_enabled = True
                    console.print("[green]Speech audio enabled.[/green]")
                elif arg in ("off", "0", "false"):
                    voice.tts_enabled = False
                    console.print("[yellow]Speech audio disabled (silent mode).[/yellow]")
            else:
                state = "ON" if voice.tts_enabled else "OFF"
                console.print(f"[cyan]Spoken voice is currently: [bold]{state}[/bold][/cyan]")

        elif cmd_lower == "/system":
            res = execute_tool("getSystemStats", {})
            console.print(Panel(str(res.get("result", "")), title="[bold cyan]🖥️ HARDWARE DIAGNOSTICS[/bold cyan]", border_style="cyan"))

        elif cmd_lower == "/providers":
            print_providers()

        elif cmd_lower.startswith("/switch"):
            parts = user_input.split()
            if len(parts) >= 2:
                prov = parts[1].lower().replace("/", "")
                key = parts[2].strip() if len(parts) > 2 else ""
                p_info = providers.get_provider_by_id(prov)
                if not p_info:
                    console.print(f"[yellow]Unknown provider '{prov}'. Type /providers to see available options.[/yellow]")
                else:
                    config.provider = prov
                    if key:
                        config.set_api_key(prov, key)
                    agent.init_provider()
                    console.print(f"[bold green]✓ Switched AI Provider to: {p_info['name']} (Model: {config.get_default_model(prov)})[/bold green]")
            else:
                print_providers()
                console.print("[dim cyan]Type [bold bright_white]/switch <id>[/bold bright_white] to activate a provider.[/dim cyan]")

        elif cmd_lower.startswith("/key"):
            parts = user_input.split()
            if len(parts) >= 3:
                prov = parts[1].lower()
                val = parts[2].strip()
                config.set_api_key(prov, val)
                agent.init_provider()
                console.print(f"[bold green]✓ API key for '{prov}' saved permanently to .env.[/bold green]")
            else:
                console.print("[yellow]Usage: /key <provider_id> <your_key> (e.g. /key groq gsk_...)[/yellow]")

        else:
            # Standard conversational AI query
            handle_user_query(user_input)


if __name__ == "__main__":
    main()

"""
Configuration management for Prime AI.
Loads environment variables and provides convenient helpers.
"""

from __future__ import annotations

import os
from pathlib import Path
from dotenv import load_dotenv, set_key

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

# Load environment
if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()


class Config:
    def __init__(self):
        self.reload()

    def reload(self):
        if ENV_PATH.exists():
            load_dotenv(dotenv_path=ENV_PATH, override=True)

        self.gemini_api_key = (
            os.getenv("GEMINI_API_KEY")
            or os.getenv("GOOGLE_API_KEY")
            or ""
        ).strip()
        self.groq_api_key = (os.getenv("GROQ_API_KEY") or "").strip()
        self.openai_api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
        self.openai_base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()

        self.provider = (os.getenv("AI_PROVIDER") or "auto").strip().lower()
        self.model = (os.getenv("AI_MODEL") or "").strip()

        self.voice_output = os.getenv("VOICE_OUTPUT", "true").strip().lower() in ("true", "1", "yes")
        try:
            self.voice_rate = int(os.getenv("VOICE_RATE", "185"))
        except ValueError:
            self.voice_rate = 185

        try:
            self.voice_volume = float(os.getenv("VOICE_VOLUME", "1.0"))
        except ValueError:
            self.voice_volume = 1.0

        self.tts_voice = os.getenv("TTS_VOICE", "en-GB-RyanNeural").strip()
        self.default_model = self.get_default_model(self.get_active_provider())

    def get_active_provider(self) -> str:
        """Determine which provider to use based on configuration and available keys."""
        if self.provider in ("gemini", "google") and self.gemini_api_key:
            return "gemini"
        if self.provider == "groq" and self.groq_api_key:
            return "groq"
        if self.provider in ("openai", "cerebras", "github", "openrouter", "mistral", "deepseek", "custom") and (self.openai_api_key or self.groq_api_key):
            return self.provider

        # Auto-detection
        if self.gemini_api_key:
            return "gemini"
        if self.groq_api_key:
            return "groq"
        if self.openai_api_key:
            return "openai"

        return "none"

    def get_default_model(self, provider: str) -> str:
        if self.model:
            return self.model
        if provider in ("gemini", "google"):
            return "gemini-3.6-flash"
        if provider == "groq":
            return "llama-3.3-70b-versatile"
        if provider == "cerebras":
            return "llama3.3-70b"
        if provider == "github":
            return "gpt-4o"
        if provider == "openrouter":
            return "meta-llama/llama-3.3-70b-instruct:free"
        if provider == "mistral":
            return "codestral-latest"
        if provider == "deepseek":
            return "deepseek-chat"
        if provider == "openai":
            return "gpt-4o-mini"
        return "gemini-3.6-flash"

    def set_api_key(self, provider: str, key: str) -> None:
        """Update and persist an API key to the .env file."""
        key = key.strip()
        if not ENV_PATH.exists():
            ENV_PATH.touch()

        if provider.lower() in ("gemini", "google"):
            set_key(str(ENV_PATH), "GEMINI_API_KEY", key)
            self.gemini_api_key = key
        elif provider.lower() == "groq":
            set_key(str(ENV_PATH), "GROQ_API_KEY", key)
            self.groq_api_key = key
        elif provider.lower() == "cerebras":
            set_key(str(ENV_PATH), "CEREBRAS_API_KEY", key)
        elif provider.lower() == "github":
            set_key(str(ENV_PATH), "GITHUB_TOKEN", key)
        elif provider.lower() == "openrouter":
            set_key(str(ENV_PATH), "OPENAI_API_KEY", key)
            set_key(str(ENV_PATH), "OPENROUTER_API_KEY", key)
        elif provider.lower() == "mistral":
            set_key(str(ENV_PATH), "MISTRAL_API_KEY", key)
        elif provider.lower() == "deepseek":
            set_key(str(ENV_PATH), "DEEPSEEK_API_KEY", key)
        elif provider.lower() == "nvidia":
            set_key(str(ENV_PATH), "NVIDIA_API_KEY", key)
        elif provider.lower() == "cloudflare":
            set_key(str(ENV_PATH), "CLOUDFLARE_API_KEY", key)
        else:
            set_key(str(ENV_PATH), f"{provider.upper()}_API_KEY", key)
            set_key(str(ENV_PATH), "OPENAI_API_KEY", key)
            self.openai_api_key = key

        self.reload()

    def set_active_provider(self, provider: str, model: Optional[str] = None) -> None:
        """Persist selected provider and optional model to .env."""
        if not ENV_PATH.exists():
            ENV_PATH.touch()
        set_key(str(ENV_PATH), "AI_PROVIDER", provider)
        self.provider = provider
        if model:
            set_key(str(ENV_PATH), "AI_MODEL", model)
            self.model = model
        self.reload()


config = Config()

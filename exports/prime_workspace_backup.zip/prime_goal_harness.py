"""
prime_goal_harness.py — Persistent Goal Tracking & Continual Harness (Inspired by PrimeIntellect prime-agent).
Manages long-running autonomous objectives, progress checkpoints, and self-improving memory lessons.
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

GOALS_FILE = Path(__file__).resolve().parent / "memory" / "active_goals.json"
LESSONS_FILE = Path(__file__).resolve().parent / "memory" / "continual_lessons.json"


def _ensure_storage():
    GOALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not GOALS_FILE.exists():
        GOALS_FILE.write_text(json.dumps({"active_goal": None, "history": []}, indent=2), encoding="utf-8")
    if not LESSONS_FILE.exists():
        LESSONS_FILE.write_text(json.dumps([], indent=2), encoding="utf-8")


class GoalTracker:
    def __init__(self):
        _ensure_storage()

    def get_active_goal(self) -> Optional[Dict[str, Any]]:
        try:
            data = json.loads(GOALS_FILE.read_text(encoding="utf-8"))
            return data.get("active_goal")
        except Exception:
            return None

    def set_goal(self, objective: str, subtasks: Optional[List[str]] = None) -> Dict[str, Any]:
        _ensure_storage()
        try:
            data = json.loads(GOALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {"active_goal": None, "history": []}

        # If previous goal was active, archive it
        if data.get("active_goal"):
            data["history"].append(data["active_goal"])

        goal = {
            "objective": objective.strip(),
            "status": "IN_PROGRESS",
            "progress_percent": 0.0,
            "subtasks": [{"title": st, "done": False} for st in (subtasks or [])],
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "notes": ["Goal initiated."]
        }
        data["active_goal"] = goal
        GOALS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return goal

    def update_progress(self, progress_pct: float, note: str = "", status: str = "IN_PROGRESS") -> Optional[Dict[str, Any]]:
        _ensure_storage()
        try:
            data = json.loads(GOALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return None

        goal = data.get("active_goal")
        if not goal:
            return None

        goal["progress_percent"] = max(0.0, min(100.0, float(progress_pct)))
        goal["status"] = status
        goal["updated_at"] = datetime.now().isoformat()
        if note:
            goal["notes"].append(f"[{datetime.now().strftime('%H:%M:%S')}] {note}")

        if progress_pct >= 100.0 or status == "COMPLETED":
            goal["status"] = "COMPLETED"
            data["history"].append(goal)
            data["active_goal"] = None

        GOALS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return goal

    def complete_active_goal(self, summary: str = "Goal accomplished.") -> Optional[Dict[str, Any]]:
        return self.update_progress(100.0, note=summary, status="COMPLETED")

    def clear_active_goal(self) -> None:
        _ensure_storage()
        try:
            data = json.loads(GOALS_FILE.read_text(encoding="utf-8"))
            if data.get("active_goal"):
                data["active_goal"]["status"] = "CANCELLED"
                data["history"].append(data["active_goal"])
                data["active_goal"] = None
                GOALS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass


class ContinualHarness:
    """Self-improving memory lessons harness (Inspired by PrimeIntellect /refine)."""
    def __init__(self):
        _ensure_storage()

    def record_lesson(self, topic: str, insight: str, source: str = "user_interaction") -> Dict[str, Any]:
        _ensure_storage()
        try:
            lessons = json.loads(LESSONS_FILE.read_text(encoding="utf-8"))
        except Exception:
            lessons = []

        lesson = {
            "id": len(lessons) + 1,
            "timestamp": datetime.now().isoformat(),
            "topic": topic.strip(),
            "insight": insight.strip(),
            "source": source
        }
        lessons.append(lesson)
        LESSONS_FILE.write_text(json.dumps(lessons, indent=2), encoding="utf-8")
        return lesson

    def get_lessons(self, limit: int = 10) -> List[Dict[str, Any]]:
        _ensure_storage()
        try:
            lessons = json.loads(LESSONS_FILE.read_text(encoding="utf-8"))
            return lessons[-limit:]
        except Exception:
            return []

    def get_lessons_context_prompt(self) -> str:
        """Formats stored lessons for injection into AI system prompt."""
        lessons = self.get_lessons(limit=8)
        if not lessons:
            return ""
        lines = ["\n[CONTINUAL HARNESS LESSONS & LEARNED PATTERNS]"]
        for l in lessons:
            lines.append(f"- {l['topic']}: {l['insight']}")
        return "\n".join(lines)


goal_tracker = GoalTracker()
continual_harness = ContinualHarness()

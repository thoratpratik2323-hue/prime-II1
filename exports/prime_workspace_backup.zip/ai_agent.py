"""
AI Agent Engine for Prime AI.
Coordinates LLM reasoning, conversation state, and tool execution loop.
Supports Google Gemini and Groq, with an intelligent local command fallback.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Callable, Dict, Generator, List, Optional

from config import config
from tool_definitions import (
    TOOL_SPECS,
    execute_tool,
    get_gemini_tools,
    get_openai_tools,
)
from voice_engine import voice

log = logging.getLogger("prime.agent")

SYSTEM_PROMPT = """You are Prime, an elite Autonomous Neural Cockpit and ambient digital operator built for Pratik Thorat.
You run entirely headless without a graphical user interface, operating 24/7 via hands-free voice intelligence.
You have direct, unrestricted neural control over the user's Windows operating system, development environment, and knowledge base.

Capabilities:
- Software Engineering & Coding (Claw Code Engine): Run terminal/shell commands, surgical code patching, automated git commit & push, run unit tests, and autonomous code debugging.
- Desktop Automation: Open and close applications (Chrome, VS Code, Notepad, Calculator, Explorer), volume & media controls (Spotify, playback), window management, screen capture, and OCR.
- Knowledge & Second Brain (Obsidian RAG): Search, read, and create notes in the user's local Obsidian Vault.
- Diagnostics & Daily Routines: Live weather reports, personalized morning briefing, CPU/RAM/GPU telemetry.
- Filesystem: Create, read, search, list, move, and recycle files.

Guidelines:
1. When the user asks you to perform an action (e.g. "open notepad", "check CPU usage", "run git status", "patch the bug in my code", "check my notes on SAT"), use the appropriate tool immediately.
2. Speak concisely, clearly, and naturally like an elite AI assistant. Avoid unnecessary disclaimers.
3. If an action succeeds, briefly confirm what was done. If a tool fails, explain what happened and suggest a next step.
"""


class AIAgent:
    def __init__(self):
        self.history: List[Dict[str, Any]] = []
        self._gemini_chat = None
        self._gemini_client = None
        self._openai_client = None
        self.active_persona: Optional[Dict[str, Any]] = None
        self.init_provider()

    def get_system_prompt(self) -> str:
        prompt = SYSTEM_PROMPT
        if self.active_persona:
            prompt += f"\n\n=========================================\nACTIVE SPECIALIST PERSONA: {self.active_persona['display_name'].upper()}\n=========================================\n"
            prompt += self.active_persona.get("instructions", "")

        from prime_goal_harness import goal_tracker, continual_harness
        active_goal = goal_tracker.get_active_goal()
        if active_goal:
            prompt += f"\n\n[CURRENT PERSISTENT OPERATING GOAL]\nObjective: {active_goal['objective']}\nProgress: {active_goal['progress_percent']}%\nStatus: {active_goal['status']}"
        lessons = continual_harness.get_lessons_context_prompt()
        if lessons:
            prompt += f"\n{lessons}"

        return prompt

    def activate_persona(self, name_or_id: str) -> Optional[str]:
        """Activate an Agency Agent specialist persona."""
        import agency_roster
        agent_info = agency_roster.get_agent_by_name(name_or_id)
        if not agent_info:
            return None
        instructions = agency_roster.get_agent_instructions(agent_info)
        self.active_persona = {
            **agent_info,
            "instructions": instructions,
        }
        self.init_provider()
        return agent_info["display_name"]

    def deactivate_persona(self) -> None:
        """Reset to default Prime neural cockpit persona."""
        self.active_persona = None
        self.init_provider()

    def init_provider(self):
        """Initialize the active provider client."""
        provider = config.get_active_provider()
        if provider in ("gemini", "google") and config.gemini_api_key:
            try:
                from google import genai
                from google.genai import types

                self._gemini_client = genai.Client(api_key=config.gemini_api_key)
                model_name = config.get_default_model("gemini")
                
                # Setup chat session with system instruction and tool specs
                self._gemini_chat = self._gemini_client.chats.create(
                    model=model_name,
                    config=types.GenerateContentConfig(
                        system_instruction=self.get_system_prompt(),
                        tools=get_gemini_tools(),
                        temperature=0.7,
                    ),
                )
                log.info("Initialized Gemini client with model: %s (Persona: %s)", model_name, self.active_persona["display_name"] if self.active_persona else "Default Prime")
            except Exception as e:
                log.error("Failed to init Gemini client: %s", e)
                self._gemini_chat = None

        # Universal OpenAI-compatible client (Groq, Cerebras, GitHub, OpenRouter, Mistral, DeepSeek, etc.)
        if provider in ("groq", "openai", "cerebras", "github", "openrouter", "mistral", "deepseek", "custom") or config.groq_api_key or config.openai_api_key:
            try:
                from openai import OpenAI
                import providers

                prov_info = providers.get_provider_by_id(provider)
                base_url = config.openai_base_url or (prov_info["base_url"] if prov_info else "https://api.groq.com/openai/v1")
                api_key = config.openai_api_key or config.groq_api_key or "no-key"

                self._openai_client = OpenAI(base_url=base_url, api_key=api_key)
                log.info("Initialized OpenAI-compatible client for %s at %s", provider, base_url)
            except Exception as e:
                log.error("Failed to init OpenAI-compatible client: %s", e)
                self._openai_client = None

    def reset_chat(self):
        """Reset conversational context."""
        self.history.clear()
        self.init_provider()

    def process_message(
        self,
        user_input: str,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        on_tool_result: Optional[Callable[[str, Any], None]] = None,
    ) -> str:
        """
        Process user message and return the final response string.
        Executes any requested tools in the loop.
        """
        user_input = (user_input or "").strip()
        if not user_input:
            return ""

        lower_in = user_input.lower()
        # Persona Switching Detection
        if lower_in.startswith("activate ") or "switch persona to " in lower_in or "switch to persona " in lower_in:
            target = lower_in.replace("activate ", "").replace("switch persona to ", "").replace("switch to persona ", "").replace(" mode", "").strip()
            if target in ("prime", "default", "cockpit", "normal"):
                self.deactivate_persona()
                msg = "Default Prime Neural Cockpit persona restored, Sir. All systems standard."
                if voice.tts_enabled:
                    voice.speak(msg)
                return msg
            activated = self.activate_persona(target)
            if activated:
                msg = f"Specialist Persona **{activated}** activated. Ready for specialized operations, Sir."
                if voice.tts_enabled:
                    voice.speak(msg)
                return msg

        if lower_in in ("reset persona", "deactivate persona", "restore prime", "default persona"):
            self.deactivate_persona()
            msg = "Specialist persona deactivated. Prime Autonomous Neural Cockpit online."
            if voice.tts_enabled:
                voice.speak(msg)
            return msg

        provider = config.get_active_provider()

        # 1. If provider is Gemini
        if provider in ("gemini", "google") and self._gemini_chat is not None:
            res = self._process_gemini(user_input, on_tool_call, on_tool_result)
            if not res.startswith("I encountered an error with Gemini"):
                return res
            # Fallback to OpenAI-compatible provider if configured
            if self._openai_client is not None:
                log.info("Gemini failed, falling back to OpenAI-compatible provider...")
                return self._process_openai_compatible(user_input, on_tool_call, on_tool_result)

        # 2. If provider is an OpenAI-compatible provider
        if self._openai_client is not None:
            return self._process_openai_compatible(user_input, on_tool_call, on_tool_result)

        # 3. Fallback: Local rule-based command execution
        return self._process_local_fallback(user_input, on_tool_call, on_tool_result)

    def _process_gemini(
        self,
        user_input: str,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]],
        on_tool_result: Optional[Callable[[str, Any], None]],
    ) -> str:
        from google.genai import types

        try:
            response = self._gemini_chat.send_message(user_input)

            # Loop to handle any function calls returned by the model
            max_iterations = 8
            for _ in range(max_iterations):
                function_calls = getattr(response, "function_calls", None)
                if not function_calls:
                    break

                for call in function_calls:
                    fn_name = call.name
                    fn_args = dict(call.args or {})
                    if on_tool_call:
                        on_tool_call(fn_name, fn_args)

                    exec_res = execute_tool(fn_name, fn_args)
                    if on_tool_result:
                        on_tool_result(fn_name, exec_res)

                    # Send tool result back to Gemini
                    response = self._gemini_chat.send_message(
                        types.Part.from_function_response(
                            name=fn_name,
                            response={"result": exec_res.get("result", exec_res)},
                        )
                    )

            final_text = response.text or ""
            if voice.tts_enabled and final_text:
                voice.speak(final_text)
            return final_text
        except Exception as e:
            err = f"Gemini error: {e}"
            log.exception(err)
            return f"I encountered an error with Gemini: {e}\nFalling back to local command handling..."

    def _process_openai_compatible(
        self,
        user_input: str,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]],
        on_tool_result: Optional[Callable[[str, Any], None]],
    ) -> str:
        provider = config.get_active_provider()
        model = config.get_default_model(provider)
        tools = get_openai_tools()

        self.history.append({"role": "user", "content": user_input})
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.history[-10:]

        try:
            max_iterations = 6
            for _ in range(max_iterations):
                resp = self._openai_client.chat.completions.create(
                    model=model,
                    messages=messages,
                    tools=tools,
                    tool_choice="auto",
                )
                msg = resp.choices[0].message
                messages.append(msg)

                if not msg.tool_calls:
                    final_text = msg.content or ""
                    self.history.append({"role": "assistant", "content": final_text})
                    if voice.tts_enabled and final_text:
                        voice.speak(final_text)
                    return final_text

                # Execute tool calls
                for tc in msg.tool_calls:
                    fn_name = tc.function.name
                    try:
                        fn_args = json.loads(tc.function.arguments or "{}")
                    except Exception:
                        fn_args = {}

                    if on_tool_call:
                        on_tool_call(fn_name, fn_args)

                    exec_res = execute_tool(fn_name, fn_args)
                    if on_tool_result:
                        on_tool_result(fn_name, exec_res)

                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "name": fn_name,
                        "content": json.dumps(exec_res),
                    })

            final_text = "Action completed."
            self.history.append({"role": "assistant", "content": final_text})
            return final_text
        except Exception as e:
            log.exception("OpenAI-compatible provider error: %s", e)
            return f"Provider error: {e}"

    def _process_local_fallback(
        self,
        user_input: str,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]],
        on_tool_result: Optional[Callable[[str, Any], None]],
    ) -> str:
        """
        Local regex / heuristic dispatcher when no API key is provided or offline.
        Handles direct commands like 'open chrome', 'volume up', 'system info', etc.
        """
        lower = user_input.lower().strip()

        # 1. System Info
        if any(k in lower for k in ("system info", "cpu", "ram", "specs", "diagnostics", "status")):
            if on_tool_call:
                on_tool_call("systemInfo", {})
            res = execute_tool("systemInfo", {})
            if on_tool_result:
                on_tool_result("systemInfo", res)
            out = res.get("result", {}).get("result", "System info fetched.")
            if voice.tts_enabled:
                voice.speak(out)
            return out

        # 2. Volume controls
        if "volume up" in lower or "increase volume" in lower:
            execute_tool("volumeUp", {"amount": 10})
            msg = "Volume increased."
            if voice.tts_enabled:
                voice.speak(msg)
            return msg
        if "volume down" in lower or "decrease volume" in lower:
            execute_tool("volumeDown", {"amount": 10})
            msg = "Volume decreased."
            if voice.tts_enabled:
                voice.speak(msg)
            return msg
        if "mute" in lower:
            execute_tool("muteToggle", {})
            msg = "Mute toggled."
            if voice.tts_enabled:
                voice.speak(msg)
            return msg

        # 3. Open applications
        m_app = re.match(r"(?:open|launch|start)\s+([a-zA-Z0-9\s]+)", lower)
        if m_app:
            target = m_app.group(1).strip()
            # Check if it's a website or app
            if any(k in target for k in ("youtube", "google", "github", "reddit", "twitter")):
                execute_tool("openWebsite", {"url": target})
                msg = f"Opening {target} in browser."
                if voice.tts_enabled:
                    voice.speak(msg)
                return msg
            else:
                res = execute_tool("openApplication", {"name": target})
                msg = res.get("result", {}).get("result", f"Opened {target}.")
                if voice.tts_enabled:
                    voice.speak(msg)
                return msg

        # 4. Close application
        m_close = re.match(r"(?:close|exit|quit|kill)\s+([a-zA-Z0-9\s]+)", lower)
        if m_close:
            target = m_close.group(1).strip()
            res = execute_tool("closeApplication", {"name": target})
            msg = res.get("result", {}).get("result", f"Closed {target}.")
            if voice.tts_enabled:
                voice.speak(msg)
            return msg

        # 5. YouTube Search
        if "search youtube for" in lower or "youtube" in lower:
            q = re.sub(r"(search youtube for|youtube search|play|on youtube)", "", lower).strip()
            if q:
                execute_tool("searchYouTube", {"query": q})
                msg = f"Searching YouTube for {q}."
                if voice.tts_enabled:
                    voice.speak(msg)
                return msg

        # 6. Screenshot
        if "screenshot" in lower:
            res = execute_tool("saveScreenshot", {})
            msg = res.get("result", {}).get("result", "Screenshot captured.")
            if voice.tts_enabled:
                voice.speak(msg)
            return msg

        # 7. No API key advisory
        advisory = (
            "I heard: '" + user_input + "'.\n\n"
            "To unlock full conversational AI reasoning and multi-step tool execution,\n"
            "please configure your Gemini or Groq API key:\n"
            "  1. Run `/key <your_gemini_or_groq_key>` here in the terminal, or\n"
            "  2. Add GEMINI_API_KEY=... in your .env file.\n\n"
            "Basic offline commands currently work: 'open <app>', 'system info', 'volume up/down', 'screenshot'."
        )
        if voice.tts_enabled:
            voice.speak("Please configure an API key for full conversational capabilities.")
        return advisory


agent = AIAgent()

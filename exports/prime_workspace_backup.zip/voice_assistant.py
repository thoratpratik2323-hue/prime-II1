"""
Prime AI — 24/7 Always-On Hands-Free Voice Assistant.
Continuously listens to microphone with high sensitivity,
processes commands directly without requiring typing,
executes desktop tools, and speaks back in realistic male voice.
"""

from __future__ import annotations

import os
import re
import sys
import time
import winsound
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

import speech_recognition as sr
from ai_agent import agent
from config import config
from tool_definitions import TOOL_SPECS
from voice_engine import voice

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

console = Console()

# By default, open-mic is enabled so you can speak directly without needing to say "Prime" first.
# If set to True, only responds when "Prime", "Jarvis", etc. is spoken.
REQUIRE_WAKE_WORD = os.getenv("REQUIRE_WAKE_WORD", "false").lower() in ("true", "1", "yes")

WAKE_WORDS = ["prime", "hey prime", "ok prime", "okay prime", "ip prime", "jarvis", "computer", "buddy", "bro"]


def play_chime(kind: str = "wake"):
    """Audible high-tech feedback tones."""
    try:
        if kind == "wake":
            winsound.Beep(988, 70)
            winsound.Beep(1318, 100)
        elif kind == "done":
            winsound.Beep(1318, 70)
            winsound.Beep(988, 90)
    except Exception:
        pass


def print_voice_header(mic_name: str):
    os.system("cls" if os.name == "nt" else "clear")

    ascii_banner = (
        "==========================================================\n"
        "    PRIME AI  ::  AUTONOMOUS NEURAL COCKPIT\n"
        "      [ Zero GUI · 24/7 Voice Driven · Pure Power ]\n"
        "=========================================================="
    )
    console.print(f"[bold cyan]{ascii_banner}[/bold cyan]")

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[bold cyan]System:[/bold cyan]", "[bold bright_white]Autonomous Digital Cockpit (Built for Pratik Thorat)[/bold bright_white]")
    table.add_row("[bold cyan]Status:[/bold cyan]", "[bold green]● LIVE 24/7 (Always Listening, Zero Typing)[/bold green]")
    table.add_row("[bold cyan]Microphone:[/bold cyan]", f"[bold]{mic_name}[/bold]")
    table.add_row("[bold cyan]Voice:[/bold cyan]", "[bold]British Male JARVIS (en-GB-RyanNeural)[/bold]")
    table.add_row("[bold cyan]AI Brain:[/bold cyan]", f"[bold]{config.get_default_model('gemini')}[/bold]")
    table.add_row("[bold cyan]Trigger Mode:[/bold cyan]", "[green]Open-Mic (Speak any command directly, or say 'Prime')[/green]")
    table.add_row("[bold cyan]Tools Active:[/bold cyan]", f"{len(TOOL_SPECS)} desktop & system automation tools")

    console.print(Panel(table, border_style="cyan", title="[bold bright_white]System Cockpit Online[/bold bright_white]"))
    console.print("[bold yellow]Simply speak into your mic:[/bold yellow] [dim]\"Open Chrome\", \"What's my CPU usage?\", \"Volume up\"[/dim]\n")


def clean_command(text: str) -> tuple[bool, str]:
    """Extract command, stripping any wake word if spoken."""
    lower = text.lower().strip()

    for kw in WAKE_WORDS:
        if lower.startswith(kw):
            clean = re.sub(rf"^{re.escape(kw)}[\s,:\.?!]*", "", lower, flags=re.IGNORECASE).strip()
            return True, clean
        elif kw in lower:
            parts = lower.split(kw, 1)
            clean = parts[1].strip(" ,:;.?!")
            return True, clean

    if REQUIRE_WAKE_WORD:
        return False, ""
    return True, lower


def on_tool_call(name: str, args: dict):
    arg_summary = ", ".join(f"{k}={v!r}" for k, v in args.items()) if args else ""
    console.print(f"  [cyan]⚡ Executing:[/cyan] [bold bright_white]{name}[/bold bright_white]({arg_summary})")


def on_tool_result(name: str, result: dict):
    if result.get("ok"):
        res = result.get("result", {})
        msg = res.get("result", res) if isinstance(res, dict) else str(res)
        console.print(f"  [green]✓ Done:[/green] [dim]{msg}[/dim]")
    else:
        err = result.get("error", "Failed")
        console.print(f"  [red]✗ Error:[/red] [bold red]{err}[/bold red]")


def find_best_mic_index() -> tuple[Optional[int], str]:
    """Find the best active microphone on the system."""
    mics = sr.Microphone.list_microphone_names()
    # Prefer Realtek Microphone Array
    for idx, name in enumerate(mics):
        if "microphone array" in name.lower() and "realtek" in name.lower():
            return idx, name

    # Fallback to default
    default_name = mics[0] if mics else "Default Microphone"
    return None, default_name


def run_voice_loop():
    mic_idx, mic_name = find_best_mic_index()
    print_voice_header(mic_name)

    recognizer = sr.Recognizer()
    # High sensitivity settings
    recognizer.energy_threshold = 300
    recognizer.dynamic_energy_threshold = False  # Fixed threshold prevents locking out speech
    recognizer.pause_threshold = 0.7             # Quick response once user finishes talking
    recognizer.non_speaking_duration = 0.4

    # Startup announcement in male voice
    voice.speak("Prime online. I am listening.")

    console.print("[bold green]● LISTENING 24/7...[/bold green] [dim](Say a command anytime)[/dim]\n")

    while True:
        try:
            # Echo prevention: pause listening when Prime is speaking out loud
            if voice.is_speaking:
                time.sleep(0.15)
                continue

            with sr.Microphone(device_index=mic_idx) as source:
                audio = recognizer.listen(source, timeout=8, phrase_time_limit=14)

            if voice.is_speaking:
                continue

            console.print("  [dim cyan]⚡ Sound detected... transcribing[/dim cyan]", end="\r")

            try:
                raw_text = recognizer.recognize_google(audio).strip()
            except sr.UnknownValueError:
                # Inaudible audio or soft noise
                continue
            except sr.RequestError as e:
                console.print(f"[red]Speech recognition network error: {e}[/red]")
                time.sleep(1.0)
                continue

            if not raw_text:
                continue

            # Process spoken text
            should_run, command = clean_command(raw_text)

            if not should_run:
                continue

            play_chime("wake")
            console.print(f"\n[bold bright_white]🎤 User:[/bold bright_white] \"{raw_text}\"")

            # If user just said "Prime"
            if not command or command.strip() in WAKE_WORDS:
                acknowledgement = "Yes boss, I'm listening."
                console.print(f"[bold cyan]Prime:[/bold cyan] {acknowledgement}")
                voice.speak(acknowledgement)
                continue

            # Process command through AI Agent + Tools
            with console.status("[bold cyan]Prime is processing...[/bold cyan]", spinner="dots"):
                response = agent.process_message(
                    command,
                    on_tool_call=on_tool_call,
                    on_tool_result=on_tool_result,
                )

            console.print(f"[bold cyan]Prime:[/bold cyan]")
            console.print(Panel(response, border_style="blue", expand=False))
            console.print("\n[bold green]● LISTENING 24/7...[/bold green]\n")

        except sr.WaitTimeoutError:
            continue
        except (KeyboardInterrupt, SystemExit):
            console.print("\n[yellow]Prime Voice Assistant pausing. Goodbye![/yellow]")
            voice.speak("Voice assistant offline.")
            time.sleep(1.0)
            break
        except Exception as e:
            console.print(f"[red]Voice loop exception: {e}[/red]")
            time.sleep(1.0)


if __name__ == "__main__":
    run_voice_loop()

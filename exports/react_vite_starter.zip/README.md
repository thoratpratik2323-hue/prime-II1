# React Vite Starter Kit

Run `npm install` and `npm run dev` to launch!
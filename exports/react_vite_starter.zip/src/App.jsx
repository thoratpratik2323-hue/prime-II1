import React from "react";
import { Sparkles } from "lucide-react";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center font-sans">
      <h1 className="text-4xl font-bold flex items-center gap-3 text-cyan-400">
        <Sparkles /> Prime AI React Starter
      </h1>
    </div>
  );
}
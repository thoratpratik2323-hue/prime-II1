# FastAPI Starter Kit

Run `pip install -r requirements.txt` and `python main.py`!
from fastapi import FastAPI
import uvicorn

app = FastAPI(title="Prime Autonomous API", version="1.0.0")

@app.get("/")
def read_root():
    return {"status": "ONLINE", "message": "FastAPI Server Ready"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=5000, reload=True)